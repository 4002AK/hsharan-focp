
import random
import time
import json  # For loading responses from a JSON file
from datetime import datetime

# Step 1: Greeting and Agent Name
def generate_agent_name():
    agent_names = ["Alex", "Jordan", "Taylor", "Casey", "Riley"]
    return random.choice(agent_names)

def greet_user():
    user_name = input("Welcome to Poppleton University Chat! What's your name? ")
    agent_name = generate_agent_name()
    print(f"Hi {user_name}, I'm {agent_name}, your virtual assistant! How can I help you today?")
    return user_name, agent_name

# Step 2: Keyword Detection and Responses
def load_responses():
    # Load keyword-response mapping from a JSON file
    try:
        with open("responses.json", "r") as file:
            return json.load(file)
    except FileNotFoundError:
        print("Error: responses.json file not found. Using default responses.")
        return {
            "coffee": "The campus coffee bar is open from 8 AM to 8 PM.",
            "library": "The library is open from 7 AM to 11 PM on weekdays.",
            "admission": "You can find admission details on our website or contact the admissions office.",
            "sports": "We have a range of sports facilities including a gym, swimming pool, and courts.",
            "thank you":"You are welcome."
        }

def get_random_response():
    random_responses = [
        "That's interesting! Tell me more.",
        "Hmm, I'm not sure about that. Could you elaborate?",
        "I see. Let me look into that for you!",
        "Great question! What else would you like to know?"
    ]
    return random.choice(random_responses)

# Step 3: Main Chat Loop
def chat(user_name, agent_name):
    responses = load_responses()
    session_log = []

    while True:
        user_input = input(f"{user_name}: ").lower()
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        session_log.append((timestamp, user_name, user_input))

        if user_input in ["bye", "quit", "exit"]:
            print(f"{agent_name}: Goodbye, {user_name}! Have a great day!")
            break

        # Random disconnection feature
        if random.random() < 0.1:  # 10% chance to disconnect randomly
            print(f"{agent_name}: Oops! It seems like we got disconnected. Please reconnect later.")
            break

        # Check for keywords
        response = None
        for keyword, reply in responses.items():
            if keyword in user_input:
                response = reply
                break

        # Simulate typing delay
        time.sleep(random.uniform(1, 2))

        # Respond to user
        if response:
            print(f"{agent_name}: {response}")
        else:
            fallback_response = get_random_response()
            print(f"{agent_name}: {fallback_response}")

        session_log.append((timestamp, agent_name, response or fallback_response))

    # Save session log to file
    save_session_log(session_log)

# Step 4: Session Logging
def save_session_log(session_log):
    with open("chat_session_log.txt", "a") as log_file:
        log_file.write("\nNew Chat Session:\n")
        for timestamp, speaker, message in session_log:
            log_file.write(f"[{timestamp}] {speaker}: {message}\n")

# Main Program
if __name__ == "__main__":
    user_name, agent_name = greet_user()
    chat(user_name, agent_name)


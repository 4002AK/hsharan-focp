from collections import Counter
import string

def most_common_letters(message):
    # Convert the message to lowercase to make it case-insensitive
    message = message.lower()

    # Filter out non-alphabetical characters (ignore digits, punctuation, etc.)
    filtered_message = ''.join([char for char in message if char in string.ascii_lowercase])

    # Count the frequency of each letter using Counter
    letter_counts = Counter(filtered_message)

    # Get the six most common letters
    most_common = letter_counts.most_common(6)

    # Print the results
    print("The six most common letters are:")
    for letter, count in most_common:
        print(f"{letter}: {count}")

# Example usage
message = input("Enter a message: ")
most_common_letters(message)


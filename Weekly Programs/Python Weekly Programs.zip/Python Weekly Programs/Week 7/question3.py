# Initialize an empty dictionary to store countries and their capital cities
countries = {}

def get_country_capital():
    while True:
        # Prompt the user for the name of a country
        country = input("Enter the name of a country (or type 'exit' to quit): ").strip()
        
        # Check if the user wants to exit the program
        if country.lower() == 'exit':
            print("Exiting the program.")
            break
        
        # If the country is already known, display its capital
        if country in countries:
            print(f"The capital city of {country} is {countries[country]}.")
        else:
            # If the capital is unknown, ask the user to provide it
            capital = input(f"I don't know the capital of {country}. Please enter it: ").strip()
            countries[country] = capital
            print(f"Thank you! The capital of {country} has been saved.")

# Run the function to start the program
get_country_capital()


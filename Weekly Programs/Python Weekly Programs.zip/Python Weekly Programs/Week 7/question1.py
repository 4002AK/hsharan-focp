def unique_sorted_letters(s):
    """
    Returns a sorted list of all unique letters in the input string.

    Parameters:
        s (str): The input string.

    Returns:
        list: A sorted list of unique letters.
    """
    # Use a set to extract unique letters and sort the result
    return sorted(set(char for char in s if char.isalpha()))

# Example usage
if __name__ == "__main__":
    string = input("Enter a string: ")
    unique_letters = unique_sorted_letters(string)
    print(f"Unique sorted letters: {unique_letters}")

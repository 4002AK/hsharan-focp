def count_case_letters(text):

    uppercase_count = sum(1 for char in text if char.isupper())
    lowercase_count = sum(1 for char in text if char.islower())
    return uppercase_count, lowercase_count

def test_count_case_letters():
    test_strings = [
        "Hello World!",
        "PYTHON programming",
        "12345",
        "MixedCASE123",
        "",
    ]
    for test_str in test_strings:
        upper, lower = count_case_letters(test_str)
        print(f"String: '{test_str}' -> Uppercase: {upper}, Lowercase: {lower}")


test_count_case_letters()


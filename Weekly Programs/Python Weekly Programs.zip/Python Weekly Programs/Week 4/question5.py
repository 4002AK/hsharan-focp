def celsius_to_fahrenheit(celsius):
    
    return celsius * 9 / 5 + 32

def fahrenheit_to_celsius(fahrenheit):

    return (fahrenheit - 32) * 5 / 9


def test_temperature_conversions():
    test_cases_celsius = [-40, 0, 37, 100]
    test_cases_fahrenheit = [-40, 32, 98.6, 212]
    
    print("Celsius to Fahrenheit:")
    for c in test_cases_celsius:
        f = celsius_to_fahrenheit(c)
        print(f"{c}°C -> {f:.2f}°F")
    
    print("\nFahrenheit to Celsius:")
    for f in test_cases_fahrenheit:
        c = fahrenheit_to_celsius(f)
        print(f"{f}°F -> {c:.2f}°C")


test_temperature_conversions()


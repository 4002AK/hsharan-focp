def greetings():
    
    name = input("Please enter your name: ").strip()  
    formatted_name = name.capitalize()  
    print(f"Hello, {formatted_name}! Nice to meet you!")


greetings()


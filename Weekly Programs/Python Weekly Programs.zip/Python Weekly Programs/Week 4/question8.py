def parse_temperature(temp_str):
    
    if temp_str[-1].upper() == 'C' and temp_str[:-1].replace('.', '', 1).isdigit():
        return float(temp_str[:-1])
    raise ValueError("Invalid temperature format. Must be a number followed by 'C'.")

def main():
    
    temperatures = []
    print("Enter temperatures in Celsius (e.g., 25C). Press Enter to finish.")
    
    while True:
        temp_input = input(f"Temperature {len(temperatures) + 1}: ").strip()
        if temp_input == "":  # Terminate on empty input
            break
        try:
            temp = parse_temperature(temp_input)
            temperatures.append(temp)
        except ValueError as e:
            print(e)

    if temperatures:
        max_temp = max(temperatures)
        min_temp = min(temperatures)
        mean_temp = sum(temperatures) / len(temperatures)
        
        print("\nResults:")
        print(f"Maximum temperature: {max_temp:.2f}C")
        print(f"Minimum temperature: {min_temp:.2f}C")
        print(f"Mean temperature: {mean_temp:.2f}C")
    else:
        print("No temperatures were entered.")


main()


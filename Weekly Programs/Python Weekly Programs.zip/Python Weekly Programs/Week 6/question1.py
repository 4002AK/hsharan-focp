def int_to_binary(n):
    """
    Converts a positive integer to its binary representation.

    Parameters:
        n (int): A positive integer.

    Returns:
        str: The binary representation of the number.
    """
    if n < 0:
        raise ValueError("Input must be a positive integer.")

    return bin(n)[2:]

# Example usage
if __name__ == "__main__":
    try:
        number = int(input("Enter a positive integer: "))
        print(f"Binary representation: {int_to_binary(number)}")
    except ValueError as e:
        print(e)

def simple_encrypt(message):
    """
    Encrypts a message by removing spaces and reversing the resulting string.

    Parameters:
        message (str): The message to encrypt.

    Returns:
        str: The encrypted message.
    """
    # Remove spaces and reverse the string
    return message.replace(" ", "")[::-1]

# Example usage
if __name__ == "__main__":
    message = input("Enter a message to encrypt: ")
    encrypted_message = simple_encrypt(message)
    print(f"Encrypted message: {encrypted_message}")

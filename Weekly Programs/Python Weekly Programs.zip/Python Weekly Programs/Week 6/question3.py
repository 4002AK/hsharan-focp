def is_prime(n):
    """
    Determines if a given integer is a prime number.

    Parameters:
        n (int): The integer to check.

    Returns:
        bool: True if the number is prime, False otherwise.
    """
    if n <= 1:
        return False

    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False

    return True

# Example usage
if __name__ == "__main__":
    try:
        number = int(input("Enter an integer: "))
        if is_prime(number):
            print(f"{number} is a prime number.")
        else:
            print(f"{number} is not a prime number.")
    except ValueError as e:
        print("Invalid input. Please enter an integer.")

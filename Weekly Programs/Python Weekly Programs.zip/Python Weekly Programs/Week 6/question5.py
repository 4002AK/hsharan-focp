import random
import string

def random_encrypt(message):
    """
    Encrypts a message by spacing its letters at random intervals and filling the gaps with random letters.

    Parameters:
        message (str): The message to encrypt.

    Returns:
        tuple: The encrypted message and the interval used.
    """
    # Generate a random interval between 2 and 20
    interval = random.randint(2, 20)

    # Prepare the encrypted message
    encrypted_message = []
    for char in message:
        # Add the actual character
        encrypted_message.append(char)
        # Fill the gap with random letters of size (interval - 1)
        encrypted_message.extend(random.choices(string.ascii_lowercase, k=interval - 1))

    # Join the list into a single string
    encrypted_message = ''.join(encrypted_message)

    return encrypted_message, interval

# Example usage
if __name__ == "__main__":
    message = input("Enter a message to encrypt: ")
    encrypted_message, interval = random_encrypt(message.replace(" ", ""))
    print(f"Encrypted message: {encrypted_message}")
    print(f"Interval used: {interval}")

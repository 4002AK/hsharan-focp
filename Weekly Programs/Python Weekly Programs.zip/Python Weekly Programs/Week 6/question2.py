def find_factors(n):
    """
    Returns the factors of an integer.

    Parameters:
        n (int): The integer to find factors of.

    Returns:
        list: A list of factors of the integer.
    """
    if n == 0:
        raise ValueError("Zero does not have factors.")

    factors = []
    for i in range(1, abs(n) + 1):
        if n % i == 0:
            factors.append(i)

    return factors

# Example usage
if __name__ == "__main__":
    try:
        number = int(input("Enter an integer: "))
        print(f"Factors: {find_factors(number)}")
    except ValueError as e:
        print(e)

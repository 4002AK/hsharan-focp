# Greeting program with name check
name = input("Please enter your name: ")

# Check if the name is empty (user pressed enter without typing a name)
if name == "":
    print("Hello, Stranger!")
else:
    print(f"Hello, {name}!")


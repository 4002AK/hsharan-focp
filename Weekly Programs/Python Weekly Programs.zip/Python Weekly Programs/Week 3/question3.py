# Password set program with length validation

# Prompt the user for a password
password1 = input("Enter a new password (8-12 characters): ")

# Check if the password length is within the valid range
if len(password1) < 8 or len(password1) > 12:
    print("Error: Password must be between 8 and 12 characters.")
else:
    # Prompt the user for the password again
    password2 = input("Confirm your password: ")

    # Check if the two passwords match
    if password1 == password2:
        print("Password set successfully!")
    else:
        print("Error: Passwords do not match. Please try again.")


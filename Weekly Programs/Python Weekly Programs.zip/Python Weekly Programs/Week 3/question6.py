# Seven Times Table program

# Loop through numbers 0 to 12
for i in range(13):
    print(f"{i} x 7 = {i * 7}")


# Times Table program with user input

# Prompt the user to enter a number for the times table
number = int(input("Enter a number between 0 and 12 to display its times table: "))

# Check if the number is within the valid range
if 0 <= number <= 12:
    # Loop through numbers 0 to 12
    for i in range(13):
        print(f"{i} x {number} = {i * number}")
else:
    print("Error: Please enter a number between 0 and 12.")


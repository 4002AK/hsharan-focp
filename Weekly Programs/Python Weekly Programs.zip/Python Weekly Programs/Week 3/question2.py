# Password set program

# Prompt the user for a password
password1 = input("Enter a new password: ")

# Prompt the user for the password again
password2 = input("Confirm your password: ")

# Check if the two passwords match
if password1 == password2:
    print("Password set successfully!")
else:
    print("Error: Passwords do not match. Please try again.")


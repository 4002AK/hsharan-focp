# Password set program with repeated prompts until successful input

# List of common passwords
BAD_PASSWORDS = ['password', 'letmein', 'sesame', 'hello', 'justinbieber']

while True:
    # Prompt the user for a password
    password1 = input("Enter a new password (8-12 characters): ")

    # Check if the password length is within the valid range
    if len(password1) < 8 or len(password1) > 12:
        print("Error: Password must be between 8 and 12 characters.")
    elif password1 in BAD_PASSWORDS:
        print(f"Error: '{password1}' is too common. Please choose a different password.")
    else:
        # Prompt the user for the password again
        password2 = input("Confirm your password: ")

        # Check if the two passwords match
        if password1 == password2:
            print("Password set successfully!")
            break  # Exit the loop once the password is successfully set
        else:
            print("Error: Passwords do not match. Please try again.")


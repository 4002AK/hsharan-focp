# Times Table program with user input and reverse functionality

# Prompt the user to enter a number for the times table
number = int(input("Enter a number between -12 and 12 to display its times table: "))

# Check if the number is within the valid range
if -12 <= number <= 12:
    # If the number is positive or zero, print the table normally
    if number >= 0:
        for i in range(13):
            print(f"{i} x {number} = {i * number}")
    # If the number is negative, print the table in reverse
    else:
        for i in range(12, -1, -1):
            print(f"{i} x {number} = {i * number}")
else:
    print("Error: Please enter a number between -12 and 12.")


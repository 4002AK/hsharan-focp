import sys

def compare_files(file1, file2):
    try:
        # Open both files in binary read mode to ensure comparison of contents
        with open(file1, 'rb') as f1, open(file2, 'rb') as f2:
            # Compare the contents of the files
            if f1.read() == f2.read():
                print(f"The files {file1} and {file2} are the same.")
            else:
                print(f"The files {file1} and {file2} are different.")
                
    except FileNotFoundError as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    # Check if two file arguments are passed
    if len(sys.argv) != 3:
        print("Usage: python3 diff.py <file1> <file2>")
    else:
        # Get the filenames from the command-line arguments
        file1 = sys.argv[1]
        file2 = sys.argv[2]
        # Call the function to compare the files
        compare_files(file1, file2)


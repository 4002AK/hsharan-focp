import sys

def wc(filename):
    try:
        # Initialize counters for lines and characters
        line_count = 0
        char_count = 0

        # Open the file in read mode
        with open(filename, 'r') as file:
            for line in file:
                line_count += 1  # Count each line
                char_count += len(line)  # Count characters in each line

        # Print the results
        print(f"Lines: {line_count}")
        print(f"Characters: {char_count}")

    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    # Check if a file argument is passed
    if len(sys.argv) != 2:
        print("Usage: python3 wc.py <filename>")
    else:
        # Get the filename from the command-line argument
        filename = sys.argv[1]
        # Call the function to count lines and characters
        wc(filename)


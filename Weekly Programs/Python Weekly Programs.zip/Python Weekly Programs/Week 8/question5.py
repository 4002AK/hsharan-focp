import sys
import enchant
import re

def spell_check(filename):
    # Initialize the dictionary for English
    d = enchant.Dict("en_US")
    
    try:
        with open(filename, 'r') as file:
            # Iterate through each line in the file
            for line in file:
                # Use regex to split the line into words, ignoring punctuation
                words = re.findall(r'\b\w+\b', line.lower())  # Convert to lowercase for case-insensitivity
                # Check each word in the line
                for word in words:
                    if not d.check(word):  # If the word is not in the dictionary
                        print(f"Misspelled word: {word}")
                        
    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    # Check if a file argument is passed
    if len(sys.argv) != 2:
        print("Usage: python3 spellcheck.py <filename>")
    else:
        # Get the filename from the command-line argument
        filename = sys.argv[1]
        # Call the function to check the spelling in the file
        spell_check(filename)


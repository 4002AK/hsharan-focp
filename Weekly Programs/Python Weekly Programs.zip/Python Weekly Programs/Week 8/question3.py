import sys

def grep(pattern, filename):
    try:
        with open(filename, 'r') as file:
            # Iterate through each line in the file
            for line_number, line in enumerate(file, start=1):
                # Check if the pattern is in the current line
                if pattern in line:
                    # Print the line number and the line itself if the pattern is found
                    print(f"Line {line_number}: {line}", end='')

    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    # Check if both arguments are passed
    if len(sys.argv) != 3:
        print("Usage: python3 grep.py <pattern> <filename>")
    else:
        # Get the pattern and filename from the command-line arguments
        pattern = sys.argv[1]
        filename = sys.argv[2]
        # Call the function to search for the pattern in the file
        grep(pattern, filename)


import sys

def print_lines_with_numbers(filename):
    try:
        # Open the file in read mode
        with open(filename, 'r') as file:
            # Enumerate the lines, starting line numbering at 1
            for line_number, line in enumerate(file, start=1):
                # Print the line number followed by the line itself
                print(f"{line_number}\t{line}", end='')  # 'end' avoids adding extra newline

    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    # Check if a file argument is passed
    if len(sys.argv) != 2:
        print("Usage: python3 nl.py <filename>")
    else:
        # Get the filename from the command-line argument
        filename = sys.argv[1]
        # Call the function to print lines with numbers
        print_lines_with_numbers(filename)

